package com.example.employeemanagement.service;

import com.example.employeemanagement.model.Employee;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * EmployeeService manages business logic and in-memory storage using ArrayList.
 * Does not use any database.
 */
@Service
public class EmployeeService {

    // In-memory list to store employee records
    private List<Employee> employeeList = new ArrayList<>();

    // Constructor to add sample initial data for testing
    public EmployeeService() {
        employeeList.add(new Employee(101, "Rahul Sharma", "IT", 65000.0));
        employeeList.add(new Employee(102, "Priya Patel", "HR", 55000.0));
        employeeList.add(new Employee(103, "Amit Verma", "Finance", 72000.0));
    }

    // 1. Retrieve all employees
    public List<Employee> getAllEmployees() {
        return employeeList;
    }

    // 2. Retrieve employee by ID
    public Employee getEmployeeById(int id) {
        for (int i = 0; i < employeeList.size(); i++) {
            Employee emp = employeeList.get(i);
            if (emp.getId() == id) {
                return emp;
            }
        }
        return null; // Employee not found
    }

    // 3. Add new employee
    public boolean addEmployee(Employee newEmployee) {
        // Check if an employee with the same ID already exists
        for (int i = 0; i < employeeList.size(); i++) {
            if (employeeList.get(i).getId() == newEmployee.getId()) {
                return false; // Duplicate ID found
            }
        }
        employeeList.add(newEmployee);
        return true;
    }

    // 4. Update existing employee
    public Employee updateEmployee(int id, Employee updatedData) {
        for (int i = 0; i < employeeList.size(); i++) {
            Employee existingEmp = employeeList.get(i);
            if (existingEmp.getId() == id) {
                // Update fields
                existingEmp.setName(updatedData.getName());
                existingEmp.setDepartment(updatedData.getDepartment());
                existingEmp.setSalary(updatedData.getSalary());
                return existingEmp;
            }
        }
        return null; // Employee not found
    }

    // 5. Delete employee by ID
    public boolean deleteEmployee(int id) {
        for (int i = 0; i < employeeList.size(); i++) {
            if (employeeList.get(i).getId() == id) {
                employeeList.remove(i);
                return true;
            }
        }
        return false; // Employee not found
    }
}
