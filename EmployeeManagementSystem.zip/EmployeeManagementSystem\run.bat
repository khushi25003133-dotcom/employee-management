@echo off
title Employee Management System - Spring Boot REST API
cd /d "%~dp0"

echo ======================================================
echo Starting Employee Management System (Spring Boot)...
echo ======================================================

"C:\Program Files\JetBrains\IntelliJ IDEA Community Edition 2025.2.6.2\plugins\maven\lib\maven3\bin\mvn.cmd" spring-boot:run

pause
