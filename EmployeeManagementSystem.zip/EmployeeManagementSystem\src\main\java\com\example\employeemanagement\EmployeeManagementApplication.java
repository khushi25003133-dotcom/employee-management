package com.example.employeemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main entry point of the Spring Boot Employee Management System.
 */
@SpringBootApplication
public class EmployeeManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeManagementApplication.class, args);
        System.out.println("==================================================");
        System.out.println(" Employee Management REST API is Running on:      ");
        System.out.println(" http://localhost:8080/api/employees             ");
        System.out.println("==================================================");
    }
}
