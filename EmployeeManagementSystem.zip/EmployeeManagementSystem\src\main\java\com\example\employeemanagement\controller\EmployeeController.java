package com.example.employeemanagement.controller;

import com.example.employeemanagement.model.Employee;
import com.example.employeemanagement.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * EmployeeController exposes REST API endpoints for Employee operations.
 * Returns ResponseEntity with appropriate HTTP status codes (200, 201, 204, 404).
 */
@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    // Dependency Injection of EmployeeService
    @Autowired
    private EmployeeService employeeService;

    // 1. GET ALL EMPLOYEES: GET /api/employees
    // Status Code: 200 OK
    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployees() {
        List<Employee> list = employeeService.getAllEmployees();
        return ResponseEntity.ok(list);
    }

    // 2. GET EMPLOYEE BY ID: GET /api/employees/{id}
    // Status Code: 200 OK or 404 NOT FOUND
    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable int id) {
        Employee employee = employeeService.getEmployeeById(id);

        if (employee != null) {
            return ResponseEntity.ok(employee); // 200 OK
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build(); // 404 Not Found
        }
    }

    // 3. CREATE EMPLOYEE: POST /api/employees
    // Status Code: 201 CREATED or 400 BAD REQUEST (if ID already exists)
    @PostMapping
    public ResponseEntity<?> addEmployee(@RequestBody Employee employee) {
        boolean isAdded = employeeService.addEmployee(employee);

        if (isAdded) {
            return ResponseEntity.status(HttpStatus.CREATED).body(employee); // 201 Created
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Employee with ID " + employee.getId() + " already exists!"); // 400 Bad Request
        }
    }

    // 4. UPDATE EMPLOYEE: PUT /api/employees/{id}
    // Status Code: 200 OK or 404 NOT FOUND
    @PutMapping("/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable int id, @RequestBody Employee updatedData) {
        Employee updatedEmployee = employeeService.updateEmployee(id, updatedData);

        if (updatedEmployee != null) {
            return ResponseEntity.ok(updatedEmployee); // 200 OK
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build(); // 404 Not Found
        }
    }

    // 5. DELETE EMPLOYEE: DELETE /api/employees/{id}
    // Status Code: 204 NO CONTENT or 404 NOT FOUND
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable int id) {
        boolean isDeleted = employeeService.deleteEmployee(id);

        if (isDeleted) {
            return ResponseEntity.noContent().build(); // 204 No Content
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build(); // 404 Not Found
        }
    }
}
