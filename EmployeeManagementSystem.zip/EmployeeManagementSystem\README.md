# Employee Management System (Spring Boot REST API)

A clean, beginner-friendly **Employee Management System** developed using **Java 17, Spring Boot, and Maven** specifically designed for college practical examinations.

This project uses an in-memory **`ArrayList`** to store employee records. It requires **no database configuration** (no MySQL, no MongoDB, no JPA/Hibernate), ensuring 100% zero-setup execution.

---

## 📁 Project Structure

```text
EmployeeManagementSystem/
│
├── pom.xml                                   # Maven dependencies & build configuration
├── README.md                                 # Complete documentation & viva guide
├── run.bat                                   # One-click startup script for Windows
├── .gitignore                                # Git ignore configuration
│
└── src/
    ├── main/
    │   ├── java/
    │   │   └── com/
    │   │       └── example/
    │   │           └── employeemanagement/
    │   │               ├── EmployeeManagementApplication.java # Spring Boot main class
    │   │               │
    │   │               ├── model/
    │   │               │   └── Employee.java                  # Model class (POJO)
    │   │               │
    │   │               ├── service/
    │   │               │   └── EmployeeService.java           # Business logic & ArrayList storage
    │   │               │
    │   │               └── controller/
    │   │                   └── EmployeeController.java        # REST Controller & Endpoints
    │   │
    │   └── resources/
    │       └── application.properties                         # Port & app settings
    │
    └── test/
        └── java/
```

---

## 🚀 How to Run in IntelliJ IDEA (Step-by-Step)

1. Open **IntelliJ IDEA**.
2. Click **Open** (or `File -> Open...`).
3. Browse and select the **`EmployeeManagementSystem`** folder.
4. Click **Trust Project** if prompted.
5. Wait a few moments while IntelliJ detects `pom.xml` and downloads Maven dependencies.
6. In the left Project Explorer, navigate to:
   `src/main/java/com/example/employeemanagement/EmployeeManagementApplication.java`
7. Click the **Green ▶ Run Button** next to `public static void main(String[] args)` or press `Shift + F10`.
8. The console will display:
   ```text
   Tomcat started on port 8080 (http) with context path ''
   Started EmployeeManagementApplication in X.XX seconds
   ```

---

## 📬 Postman Testing Guide

Base URL: `http://localhost:8080/api/employees`

### 1. Get All Employees
- **Method:** `GET`
- **URL:** `http://localhost:8080/api/employees`
- **Status Code:** `200 OK`
- **Response:**
  ```json
  [
    { "id": 101, "name": "Rahul Sharma", "department": "IT", "salary": 65000.0 },
    { "id": 102, "name": "Priya Patel", "department": "HR", "salary": 55000.0 },
    { "id": 103, "name": "Amit Verma", "department": "Finance", "salary": 72000.0 }
  ]
  ```

---

### 2. Get Employee by ID
- **Method:** `GET`
- **URL:** `http://localhost:8080/api/employees/101`
- **Status Code:** `200 OK`
- **Response:**
  ```json
  {
    "id": 101,
    "name": "Rahul Sharma",
    "department": "IT",
    "salary": 65000.0
  }
  ```
- *If ID does not exist (e.g. `/999`):* Status Code `404 Not Found`.

---

### 3. Add New Employee
- **Method:** `POST`
- **URL:** `http://localhost:8080/api/employees`
- **Headers:** `Content-Type: application/json`
- **Body (`raw` -> `JSON`):**
  ```json
  {
    "id": 104,
    "name": "Sneha Gupta",
    "department": "Marketing",
    "salary": 60000.0
  }
  ```
- **Status Code:** `201 Created`
- **Response:**
  ```json
  {
    "id": 104,
    "name": "Sneha Gupta",
    "department": "Marketing",
    "salary": 60000.0
  }
  ```
- *If ID already exists:* Status Code `400 Bad Request` (`"Employee with ID 104 already exists!"`).

---

### 4. Update Employee Details
- **Method:** `PUT`
- **URL:** `http://localhost:8080/api/employees/101`
- **Headers:** `Content-Type: application/json`
- **Body (`raw` -> `JSON`):**
  ```json
  {
    "name": "Rahul Sharma",
    "department": "Operations",
    "salary": 70000.0
  }
  ```
- **Status Code:** `200 OK`
- **Response:**
  ```json
  {
    "id": 101,
    "name": "Rahul Sharma",
    "department": "Operations",
    "salary": 70000.0
  }
  ```
- *If ID does not exist:* Status Code `404 Not Found`.

---

### 5. Delete Employee
- **Method:** `DELETE`
- **URL:** `http://localhost:8080/api/employees/102`
- **Status Code:** `204 No Content` (Empty response body).
- *If ID does not exist:* Status Code `404 Not Found`.

---

## 🏷️ Spring Boot Annotations Explained Simply

| Annotation | Purpose in Project |
|---|---|
| `@SpringBootApplication` | Marks the main class. Enables auto-configuration, component scanning, and bootstrap of Spring context. |
| `@RestController` | Combines `@Controller` and `@ResponseBody`. Tells Spring this class handles HTTP requests and returns JSON directly. |
| `@Service` | Marks the service class holding business logic. Allows Spring to manage it as a bean. |
| `@Autowired` | Automatically injects the `EmployeeService` bean into `EmployeeController` (Dependency Injection). |
| `@RequestMapping` | Defines the base URL path (`/api/employees`) for all methods in the controller. |
| `@GetMapping` | Maps HTTP `GET` requests to retrieve data (e.g. read employees). |
| `@PostMapping` | Maps HTTP `POST` requests to create new resources. |
| `@PutMapping` | Maps HTTP `PUT` requests to update existing resources. |
| `@DeleteMapping` | Maps HTTP `DELETE` requests to delete resources. |
| `@RequestBody` | Converts the incoming JSON request body into a Java `Employee` object. |
| `@PathVariable` | Extracts dynamic values from the URL path (e.g. extracting `101` from `/api/employees/101`). |

---

## 🎓 Top Viva Questions & Answers

**Q1: What is a REST API?**
> **Ans:** REST (Representational State Transfer) is an architectural style for building web services using standard HTTP methods (GET, POST, PUT, DELETE) to transfer data in formats like JSON.

**Q2: What is the difference between `@Controller` and `@RestController`?**
> **Ans:** `@Controller` is used in traditional web apps to return HTML views. `@RestController` automatically serializes returned Java objects into JSON/XML via `@ResponseBody`.

**Q3: Why did we use `ArrayList` instead of a database?**
> **Ans:** `ArrayList` acts as an in-memory data store for demonstration and college practicals. It requires zero database configuration or external drivers.

**Q4: What is `ResponseEntity` and why do we use it?**
> **Ans:** `ResponseEntity` represents the complete HTTP response, allowing us to customize the response body, headers, and HTTP status codes (such as `200 OK`, `201 Created`, `204 No Content`, `404 Not Found`).

**Q5: What is Dependency Injection (DI) and how is `@Autowired` used?**
> **Ans:** DI is a design pattern where Spring automatically creates and supplies dependent objects. `@Autowired` injects the `EmployeeService` instance into the `EmployeeController` without using the `new` keyword.

**Q6: What is the difference between `@PathVariable` and `@RequestParam`?**
> **Ans:** `@PathVariable` extracts values directly from the URI path (e.g., `/employees/101`), whereas `@RequestParam` extracts query parameters from the URL (e.g., `/employees?id=101`).
